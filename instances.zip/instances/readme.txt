#Instances for the problem described in "A logic-based Benders decomposition approach 
for a fuel replenishment problem with time windows, unsplit compartments, and split deliveries"
#Last update: 2024/12/06

#Instance format
1 - The first line provides the value of Wmax.
2 - The second line gives the number of vehicle types (ntypes).
3 - The next ntypes lines present, for each type, respectively: the fixed cost, the time factor, the number of compartments,
the capacity of each compartment, and the loading/unloading time for each compartment.
4 - The next line shows the number of vehicles (NK) that is equal to the number of customers (NV).
5 - The next line presents NK values informing the type of each vehicle.
6 - The next NV lines show, for each customer, respectively, the x and y coordinates and the start and end of the time windows.
7 - The next NV lines give, for each customer, the demands for each of the four fuel types.

#Observations: 
a) The distances are defined as integers, obtained by rounding up the Euclidean distance between the noodes' coordinates.
b) The depot is assumed to be at (0,0) 
c) The times to cross the arcs are defined as integers, obtained by rounding up the distance multiplied by the vehicle type's time factor.
